# Astro Blog Starter

This is a simple blog starter built with Astro.