import { defineConfig } from 'astro/config';

export default defineConfig({
  site: 'https://yourdomain.com', // replace with your custom domain
  integrations: []
});
